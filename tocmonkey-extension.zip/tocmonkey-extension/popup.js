const SUBMIT_URL = 'https://tocmonkey.com/.netlify/functions/articles?type=suggest';

// Get current tab info and pre-fill
chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  const tab = tabs[0];
  if (tab) {
    document.getElementById('ft').value = tab.title || '';
    document.getElementById('fu').value = tab.url || '';
    // Try to extract publication from hostname
    try {
      const host = new URL(tab.url).hostname.replace('www.', '');
      const pubMap = {
        'warontherocks.com': 'War on the Rocks',
        'mwi.westpoint.edu': 'Modern War Institute',
        'irregularwarfare.org': 'Irregular Warfare Initiative',
        'understandingwar.org': 'ISW',
        'fpri.org': 'FPRI',
        'csis.org': 'CSIS',
        'rand.org': 'RAND',
        'foreignpolicy.com': 'Foreign Policy',
        'defensenews.com': 'Defense News',
        'taskandpurpose.com': 'Task & Purpose',
        'thedefensepost.com': 'The Defense Post',
      };
      if (pubMap[host]) document.getElementById('fp').value = pubMap[host];
    } catch(e) {}
  }
});

document.getElementById('submitBtn').addEventListener('click', async () => {
  const title = document.getElementById('ft').value.trim();
  const url   = document.getElementById('fu').value.trim();
  if (!title || !url) { showMsg('Title and URL required', 'err'); return; }

  const article = {
    title, url,
    author:      document.getElementById('fa').value.trim(),
    publication: document.getElementById('fp').value.trim(),
    date:        new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
    blurb:       document.getElementById('fb').value.trim(),
    tags:        document.getElementById('ftg').value.split(',').map(t => t.trim()).filter(Boolean)
  };

  try {
    const r = await fetch(SUBMIT_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(article)
    });
    if (r.ok) {
      showMsg('✓ SUBMITTED — Chief will review it', 'ok');
      setTimeout(() => window.close(), 2000);
    } else {
      showMsg('Error — try again', 'err');
    }
  } catch(e) {
    showMsg('Network error', 'err');
  }
});

function showMsg(text, type) {
  const el = document.getElementById('msg');
  el.textContent = text;
  el.className = type;
  el.style.display = 'block';
}
